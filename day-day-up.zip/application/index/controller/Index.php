<?php

/**
 * User:goodtimp
 * LastDate:2018/11/22
 */
namespace app\index\controller;

use think\Controller;
use think\facade\Session;


class Index extends Father
{
  public function index()
  {
    
      return view();
  }
}
